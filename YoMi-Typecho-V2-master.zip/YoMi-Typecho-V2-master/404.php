<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
<article class="error-block animated fadeInDown">
				<div class="error-info">
					<p>Error</p>
					错误：没有你要找的内容！
				</div>
			</article>
<?php $this->need('footer.php'); ?>
